
		//Define map start up options
		var mapOptions = {
			center: [41.8875, 12.72],
			zoom: 18 ,
			maxZoom : 20
			}
		
		//Creates Map Variable
		var map = new L.map('map', mapOptions); 

		//Externally called background map
			var Esri_WorldImagery = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
				attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community'
				}).addTo(map);
			
		//Function to allow for popup box containing attributes of .geoJSON files
			function popUp(f,l){
				var out = [];
				if (f.properties){
					for(key in f.properties){
						out.push(key+": "+f.properties[key]);
						}
					l.bindPopup(out.join("<br />"));
					}
				}
				
		//Style definitions for individual .geoJson layers
		var myStyle0a = {
				"color": "#ff1500",
				"weight": 2,
				"opacity": 0.5};
		var myStyle0b = {
				"color": "#04ff00",
				"weight": 2,
				"opacity": 0.5};
		var myStyle1 = {
				"color": "#0008ff",
				"weight": 2,
				"opacity": 0.5};
		var myStyle2 = {
				"color": "#ff00fa",
				"weight": 2,
				"opacity": 0.5};
		var myStyle3 = {
				"color": "#ff7b00",
				"weight": 2,
				"opacity": 0.5};	
		var myStyle4a = {
				"color": "#ff00d4",
				"weight": 2,
				"opacity": 0.5};		
		var myStyle4b = {
				"color": "#ccff00",
				"weight": 2,
				"opacity": 0.5};
		var myStyle4c = {
				"color": "#00ffe9",
				"weight": 2,
				"opacity": 0.5};
				
		//Imports geoJSON files with popUp box and designated style
		var phase0a = new L.GeoJSON.AJAX("Phase0aSUPoly.geojson", 
			{style:myStyle0a,onEachFeature:popUp, time: "Phase 0a"});       
			//phase0a.addTo(map);
		var phase0b = new L.GeoJSON.AJAX("Phase0bSUPoly.geojson", 
			{style:myStyle0b,onEachFeature:popUp, time: "Phase 0b"});       
			//phase0b.addTo(map);
		var phase1 = new L.GeoJSON.AJAX("Phase1SUPoly.geojson", 
			{style:myStyle1,onEachFeature:popUp, time: "Phase 1"});       
			//phase1.addTo(map);
		var phase2 = new L.GeoJSON.AJAX("Phase2SUPoly.geojson", 
			{style:myStyle2,onEachFeature:popUp, time: "Phase 2"});     
			//phase2.addTo(map);
		var phase3 = new L.GeoJSON.AJAX("Phase3SUPoly.geojson", 
			{style:myStyle3,onEachFeature:popUp, time: "Phase 3"});    
			//phase3.addTo(map);	
		var phase4a = new L.GeoJSON.AJAX("Phase4aSUPoly.geojson", 
			{style:myStyle4a,onEachFeature:popUp, time: "Phase 4a"});  
			//phase4a.addTo(map);
		var phase4b = new L.GeoJSON.AJAX("Phase4bSUPoly.geojson", 
			{style:myStyle4b,onEachFeature:popUp, time: "Phase 4b"});    
			//phase4b.addTo(map);
		var phase4c = new L.GeoJSON.AJAX("Phase4cSUPoly.geojson", 
			{style:myStyle4c,onEachFeature:popUp, time: "Phase 4c"});    
			//phase4c.addTo(map);	
			
		//Adds control pan from PanControl Plug In
		L.control.pan().addTo(map);
		
		//array of geoJson layers created, then made into a layerGroup
		var phases = [phase0a, phase0b, phase1, phase2, phase3, phase4a, phase4b, phase4c];
		var layerGroup = L.layerGroup(phases);
		
		//Requires LeafletSlider and JQuery plugins (locally hosted) and JQuery UI plug in (currently externally hosted)
		var sliderControl = L.control.sliderControl({
			position : 'topright', layer : layerGroup, //define location and layer to be added
			follow : true, //turns off previous layers
			alwaysShowDate : true, //always shows label, there is a bug here where it initially doesn't show you the label
			showAllOnStart: false //shows all layers when initially opened
		});
		map.addControl(sliderControl);
		sliderControl.startSlider();
		
			
